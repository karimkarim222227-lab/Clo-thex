import type { CapacitorConfig } from "@capacitor/cli";
const config: CapacitorConfig = {
  appId: "com.clowthex.app",
  appName: "Clowthex",
  webDir: "dist",
  plugins: {
    SplashScreen: {
      launchShowDuration: 2000,
      launchAutoHide: false,
      backgroundColor: "#0f0f0f",
      splashFullScreen: true,
      splashImmersive: true,
    },
    StatusBar: { style: "DARK", backgroundColor: "#0f0f0f" },
    Keyboard: { resize: "body" },
  },
};
export default config;
